﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Chain_of_Fools
{
    class Program
    {
        static void Main(string[] args)
        {
            // read data from text file into a list of strings
            const string SAMPLE_DATA = "Chain of Fools.txt";
            List<string> lines = File.ReadLines(SAMPLE_DATA).ToList();

            // variables to store input
            int s;
            int c;
            int p;
            int l;

            foreach (string dataLine in lines)
            {
                // split inputs in each line and put into an array
                string[] caseArr = dataLine.Split(' ');
                s = Convert.ToInt32(caseArr[0]);
                c = Convert.ToInt32(caseArr[1]);
                p = Convert.ToInt32(caseArr[2]);
                l = Convert.ToInt32(caseArr[3]);

                // variables to determine results
                bool broken = false;
                int m;
                int r = -1;

                // variables to keep track of case and position in loop
                int currentProng = p;
                int currentLink = l;
                int currentCase = 0;

                // increment case counter after each valid data line
                currentCase++;

                // calculate m (number of moves to complete a revolution)
                m = s - p;

                // check for last line (according to instructions)
                if (s == 0 & c == 0 & p == 0 & l == 0)
                {
                    break;
                }
                // check for invalid input
                else if(s<=1 || s>=100 || c<s || c>=200 || p>s || l>c)
                {
                    Console.WriteLine("Case " + currentCase + ": This case has invalid input");
                }
                else
                {
                    while (broken == false)
                    {
                        // if prong and link are aligned, stop calculation and print results
                        if (currentProng == 0 & currentLink == 0)
                        {
                            broken = true;
                            Console.WriteLine("Case " + currentCase + ": " + r + ' ' + m + '/' + s);
                            break;
                        }
                        // if back at starting point, print case: never
                        else if (currentProng == p & currentLink == l & r > 0)
                        {
                            Console.WriteLine("Case " + currentCase + ": Never");
                            break;
                        }
                        // increment counter (r) after each revolution
                        if (currentProng == p) { r++; }
                        // move prong and link one step further
                        currentProng++;
                        currentLink++;                        
                        // reset current variables after a full rotation
                        if (currentProng == s) { currentProng = 0;}
                        if (currentLink == c) { currentLink = 0; }
                    }
            }
    }
            //to keep console open after program has run
            Console.ReadKey();
        }
    }
}
