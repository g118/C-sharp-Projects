﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace JokeAndPunchLine
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnSetup_Click(object sender, RoutedEventArgs e) //onClick function to display the setUp 
        {
            lblOutput.Content = "Why is the prime minister not seen in the mornings?";
        }

        private void btnPunchLine_Click(object sender, RoutedEventArgs e) //onClick function to display the PunchLine
        {
            lblOutput.Content = "Because he is PM not AM!";
        }
    }
}
