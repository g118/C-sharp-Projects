﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

/// <summary>
/// Group 3
/// Problem: Card Identifier
/// Team Members:
///     Elizabeth Mathew    7477417
///     Jose Ruiz           7515984
///     Shweta Gulia        7465768
///     Sukriti Sharma      
///     Varun Ramachandran  7636814
///     Vasu Gambhir        7465776
///     Yiran Li            7588437
/// </summary>
/// 
namespace Week1
{
    /// <summary>
    /// This program shows the name of the clicked card inside a label in top part of the window.
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void twoOfHearts_Click(object sender, RoutedEventArgs e)
        {
            CardNameOutput.Content = "Two of Hearts";
        }

        private void sixOfSpades_Click(object sender, RoutedEventArgs e)
        {
            CardNameOutput.Content = "Six of Spades";
        }

        private void sevenOfSpades_Click(object sender, RoutedEventArgs e)
        {
            CardNameOutput.Content = "Seven of Spades";
        }

        private void jackOfClubs_Click(object sender, RoutedEventArgs e)
        {
            CardNameOutput.Content = "Jack of Clubs";
        }

        private void kingOfDiamonds_Click(object sender, RoutedEventArgs e)
        {
            CardNameOutput.Content = "King of Diamonds";
        }
    }
}
