﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Orion_constellation
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnShow_Click(object sender, RoutedEventArgs e)
        {
            lblAlninam.Visibility = Visibility.Visible;
            lblAnitak.Visibility = Visibility.Visible;
            lblBetelgeuse.Visibility = Visibility.Visible;
            lblMeissas.Visibility = Visibility.Visible;
            lblMintaka.Visibility = Visibility.Visible;
            lblRigel.Visibility = Visibility.Visible;
            lblSaiph.Visibility = Visibility.Visible;
           
        }

        private void btnHide_Click(object sender, RoutedEventArgs e)
        {
            lblAlninam.Visibility = Visibility.Hidden;
            lblAnitak.Visibility = Visibility.Hidden;
            lblBetelgeuse.Visibility = Visibility.Hidden;
            lblMeissas.Visibility = Visibility.Hidden;
            lblMintaka.Visibility = Visibility.Hidden;
            lblRigel.Visibility = Visibility.Hidden;
            lblSaiph.Visibility = Visibility.Hidden;
        }
    }
}
